<?php

if (! function_exists('mg_simple_banners_options')) {
    function mg_simple_banners_mg_simple_banners_options() {}
}
